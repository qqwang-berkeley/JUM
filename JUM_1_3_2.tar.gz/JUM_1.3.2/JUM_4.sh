#!/bin/bash
#set -e
# $1=directory for JUM scripts; $2=pvalue or pvalue-adjusted; $3=pvalue or padj threshold; $4=file numbers; $5=control_file_numbers; 
#############

folder="$1";
pvalue_padj="$2";
cutoff="$3";
#############


for output in AS_differential_JUM_output_A*SS*_"$pvalue_padj"_"$cutoff".txt
do
   sort_out=${output%.txt}"_"sorted.txt;
   fold_out=${sort_out%.txt}"_"reformat.txt;
   k_list=${output%.txt}"_"3k_junc_list.txt;
   foldy_list=${output%.txt}"_"fold_1.5_list.txt;
   final_list=${output%.txt}"_"fold_1.5_and_under_3k_junc_list.txt
   final_output=${output%.txt}"_"fold_1.5_and_under_3k_junction.txt
   sort -k1,1 -k2,2 -k3,3 $output > $sort_out;
   perl $folder/output_reformat_JUM_1.pl $sort_out > $fold_out;
   awk -v foldychan=1.5 '$28 >= foldychan' $fold_out | cut -f1 | sort -u > $foldy_list;
   awk -v lengchan=3000 '$14 >= lengchan' $fold_out | cut -f1 | sort -u > $k_list;
   awk 'FNR==NR {arr[$0];next} !($1 in arr)' $k_list $foldy_list > $final_list;
   awk 'FNR==NR {arr[$0];next} ($1 in arr)' $final_list $fold_out > $final_output;
done

   output=AS_differential_JUM_output_MXE_events_"$pvalue_padj"_"$cutoff".txt
   sort_out=${output%.txt}"_"sorted.txt;
   fold_out=${sort_out%.txt}"_"reformat.txt;
   k_list=${output%.txt}"_"3k_junc_list.txt;
   foldy_list=${output%.txt}"_"fold_1.5_list.txt;
   final_list=${output%.txt}"_"fold_1.5_and_under_3k_junc_list.txt
   final_output=${output%.txt}"_"fold_1.5_and_under_3k_junction.txt
   sort -k1,1 -k2,2 -k3,3 $output > $sort_out;
   perl $folder/output_reformat_JUM_1.pl $sort_out > $fold_out;
   awk -v foldychan=1.5 '$28 >= foldychan' $fold_out | cut -f1 | sort -u > $foldy_list;
   awk -v lengchan=3000 '$14 >= lengchan' $fold_out | cut -f1 | sort -u > $k_list;
   awk 'FNR==NR {arr[$0];next} !($1 in arr)' $k_list $foldy_list > $final_list;
   awk 'FNR==NR {arr[$0];next} ($1 in arr)' $final_list $fold_out > $final_output;


   output=AS_differential_JUM_output_mixed_events_"$pvalue_padj"_"$cutoff".txt
   sort_out=${output%.txt}"_"sorted.txt;
   fold_out=${sort_out%.txt}"_"reformat.txt;
   k_list=${output%.txt}"_"3k_junc_list.txt;
   foldy_list=${output%.txt}"_"fold_1.5_list.txt;
   final_list=${output%.txt}"_"fold_1.5_and_under_3k_junc_list.txt
   final_output=${output%.txt}"_"fold_1.5_and_under_3k_junction.txt
   sort -k1,1 -k2,2 -k3,3 $output > $sort_out;
   perl $folder/output_reformat_JUM_1.pl $sort_out > $fold_out;
   awk -v foldychan=1.5 '$28 >= foldychan' $fold_out | cut -f1 | sort -u > $foldy_list;
   awk -v lengchan=3000 '$14 >= lengchan' $fold_out | cut -f1 | sort -u > $k_list;
   awk 'FNR==NR {arr[$0];next} !($1 in arr)' $k_list $foldy_list > $final_list;
   awk 'FNR==NR {arr[$0];next} ($1 in arr)' $final_list $fold_out > $final_output;

    cassette=AS_differential_JUM_output_cassette_exon_events_"$pvalue_padj"_"$cutoff".txt
    cassett_sort=${cassette%.txt}"_"sorted.txt;
    cassett_fold=${cassette%.txt}"_"reformat.txt;
    k_list=${cassette%.txt}"_"3k_junc_list.txt;
    foldy_list=${cassette%.txt}"_"fold_1.5_list.txt;
    final_list=${cassette%.txt}"_"fold_1.5_and_under_3k_junc_list.txt
    final_output=${cassette%.txt}"_"fold_1.5_and_under_3k_junction.txt
    sort -k1,1 -k2,2 -k3,3 $cassette > $cassett_sort;
    perl $folder/output_reformat_JUM_2.pl $cassett_sort > $cassett_fold;
    awk -v foldychan=1.5 '$32 >= foldychan' $cassett_fold | cut -f1 | sort -u > $foldy_list;
    awk -v lengchan=3000 '$14 >= lengchan' $cassett_fold | cut -f1 | sort -u > $k_list;
    awk 'FNR==NR {arr[$0];next} !($1 in arr)' $k_list $foldy_list > $final_list;
    awk 'FNR==NR {arr[$0];next} ($1 in arr)' $final_list $cassett_fold > $final_output;


    intron=AS_differential_JUM_output_intron_retention_"$pvalue_padj"_"$cutoff".txt
    intron_sort=${intron%.txt}"_"sorted.txt;
    intron_fold=${intron%.txt}"_"reformat.txt;
    k_list=${intron%.txt}"_"3k_junc_list.txt;
    foldy_list=${intron%.txt}"_"fold_1.5_list.txt;
    final_list=${intron%.txt}"_"fold_1.5_and_under_3k_junc_list.txt
    final_output=${intron%.txt}"_"fold_1.5_and_under_3k_junction.txt
    sort -k1,1 -k2,2 -k3,3 $intron > $intron_sort;
    perl $folder/output_reformat_JUM_3.pl $intron_sort > $intron_fold;
    awk -v foldychan=1.5 '$32 >= foldychan' $intron_fold | cut -f1 | sort -u > $foldy_list;
    awk -v lengchan=3000 '$14 >= lengchan' $intron_fold | cut -f1 | sort -u > $k_list;
    awk 'FNR==NR {arr[$0];next} !($1 in arr)' $k_list $foldy_list > $final_list;
    awk 'FNR==NR {arr[$0];next} ($1 in arr)' $final_list $intron_fold > $final_output;
