#!/bin/bash
set -e
# $1=directory for JUM scripts; $2=threshold for junction reads; $3=read # threshold for intron_exon boundary reads; $4=read length; $5=file number
#############$5=experiment design txt file
################################# 
folder="$1";
threshold="$2";
#read_length="$4";
#file_num="$5";
##################################
#stranded="$4";
##########exp_design="$5";


less UNION_mixed_event_screening_formatted.txt | cut -f5 | sort > UNION_mixed_event_screening_formatted_junction_list.txt;

less UNION_mixed_event_screening_formatted.txt | cut -f1,2,3 | sort | uniq -d > mixed_AS_more_than_"$threshold"_union_junc_coor_5_prime_ss_list_with_alternative_3_ss.txt;

perl $folder/profile_AS_events_sharing_5_prime_ss.pl UNION_mixed_event_screening_formatted.txt mixed_AS_more_than_"$threshold"_union_junc_coor_5_prime_ss_list_with_alternative_3_ss.txt > mixed_AS_more_than_"$threshold"_profiled_5_ss_and_corresponding_alternative_3_ss_junction_list.txt;

less UNION_mixed_event_screening_formatted.txt | cut -f1,2,4 | sort | uniq -d > mixed_AS_more_than_"$threshold"_union_junc_coor_3_prime_ss_list_with_alternative_5_ss.txt;

perl $folder/profile_AS_events_sharing_3_prime_ss.pl UNION_mixed_event_screening_formatted.txt mixed_AS_more_than_"$threshold"_union_junc_coor_3_prime_ss_list_with_alternative_5_ss.txt > mixed_AS_more_than_"$threshold"_profiled_3_ss_and_corresponding_alternative_5_ss_junction_list.txt;

cat mixed_AS_more_than_"$threshold"_profiled_5_ss_and_corresponding_alternative_3_ss_junction_list.txt mixed_AS_more_than_"$threshold"_profiled_3_ss_and_corresponding_alternative_5_ss_junction_list.txt > mixed_AS_more_than_"$threshold"_profiled_total_AS_event_junction.txt;

perl $folder/first_processing_generate_JUM_reference_for_profiled_total_alternative_splicing_event_junction.pl mixed_AS_more_than_"$threshold"_profiled_total_AS_event_junction.txt mixed_AS_more_than_"$threshold"_profiled_total_AS_event_junction_first_processing_for_JUM_reference_building.txt;
