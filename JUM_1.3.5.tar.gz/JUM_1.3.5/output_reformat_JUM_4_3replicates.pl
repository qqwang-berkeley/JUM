#!/usr/bin/perl
use strict;
use warnings;
use List::Util qw( min max );
use List::Util qw(sum);
#data_file_1=non_zero_profiled_total_alternative_splicing_event_junction_first_processing_for_DEXSeq_reference_building.txt; 

my $len=scalar(@ARGV);
if ($len < 1) {
    die "Usage:output_reformat_3.pl <data_file_1>\n";

}

my ($data_file_1)  = @ARGV;

my $o=0;
my %hash; #$hash{chr}{strand}{start}{end}=[count_number];
open(IN1, "<$data_file_1") or die "can't open input1 file: $!";

my @enter_1;
$#enter_1=6;
my @enter_2;
$#enter_2=6;
my $count=0;

while(<IN1>) {
      chomp;
    if($_ !~ /raw_count/) {
      $count=$count+1;
      my $ori=$_;
      my @array=split(/\s+/,$_);
         if($count % 2 == 1) {
           $enter_1[0]=$array[15];
           $enter_1[1]=$array[16];
           $enter_1[2]=$array[17];
           $enter_1[3]=$array[18];
           $enter_1[4]=$array[19];
           $enter_1[5]=$array[20];
	   print $ori; print "\n";
         } 
         if($count % 2 == 0) {
           $enter_2[0]=$array[15];
           $enter_2[1]=$array[16];
           $enter_2[2]=$array[17];
           $enter_2[3]=$array[18];
           $enter_2[4]=$array[19];
           $enter_2[5]=$array[20];
           my $ratio_a=$enter_1[0]/($enter_2[0]+$enter_1[0]);
	   my $ratio_b=$enter_1[1]/($enter_2[1]+$enter_1[1]);
           my $ratio_c=$enter_1[2]/($enter_2[2]+$enter_1[2]);
           my $ratio_d=$enter_1[3]/($enter_2[3]+$enter_1[3]);
	   my $ratio_e=$enter_1[4]/($enter_2[4]+$enter_1[4]);
           my $ratio_f=$enter_1[5]/($enter_2[5]+$enter_1[5]);
           my $av1=sum($ratio_a,$ratio_b,$ratio_c)/3;
	   my $av2=sum($ratio_d,$ratio_e,$ratio_f)/3;
	   #my $ma=max($av1,$av2);
	   #my $mi=min($av1,$av2);
	   #my $fold=$ma/$mi/2;
	   my $dpsi=$av1-$av2;
           print $ori; print "\t"; print $dpsi; print "\n"; #print $ratio_a; print "\t";print $ratio_b; print "\t";print $ratio_c; print "\t";print $ratio_d; print "\t"; print $av1; print "\t"; print $av2; print "\t"; print $ma; print "\t"; print $mi; print "\t"; print $fold; print "\n";         }
   }
   }
     else {
       print $_; print "\t"; print "deltaPSI"; print "\n";
   }
}



   
   
   
   
       



