#!/bin/bash
set -e
# $1=directory for JUM scripts; $2=threshold for junction reads; $3=read # threshold for intron_exon boundary reads; $4=read length;
#############$5=experiment design txt file
################################# 
folder="$1";
threshold="$2";
folder_name="$3";
##################################
#stranded="$4";
##########exp_design="$5";

#Step 1
for file in *SJ.out.tab_strand_symbol_scaled;
do
    na1=${file%SJ.out.tab_strand_symbol_scaled}"_"idxstats_junction.txt;
    na2=${file%SJ.out.tab_strand_symbol_scaled}"_"junction_counts.txt;
    na3=${file%SJ.out.tab_strand_symbol_scaled}"_"idxstats_junction_less_than_"$threshold".txt;
    perl $folder/prepare_count_file_after_STAR_2_pass_mapping.pl $file UNION_junc_coor_with_junction_ID.txt $na1;
    awk '{print $1 "\t" $4 "\t" $2 "\t" $3 "\t" $10 "\t" $7 "\t" $9}' $na1 > $na2;
    awk -v env_threshold="$threshold" '$7 < env_threshold' $na1 > $na3;
done

cat *idxstats_junction_less_than_$threshold.txt | cut -f10 | sort -u > junction_list_count_less_than_"$threshold"_union_from_all_samples.txt;
awk 'FNR==NR {arr[$0];next} !($5 in arr)' junction_list_count_less_than_"$threshold"_union_from_all_samples.txt UNION_junc_coor_with_junction_ID.txt > "$folder_name"_junc_coor_with_junction_ID_more_than_"$threshold"_reads.txt;

perl $folder/Identify_junctions_exist_in_all_samples.pl "$folder_name"_junc_coor_with_junction_ID_more_than_"$threshold"_reads.txt *_junction_counts.txt "$folder_name"_overlap_second_pass_junction_list_from_all_samples.txt;

awk 'FNR==NR {arr[$0];next} ($5 in arr)' "$folder_name"_overlap_second_pass_junction_list_from_all_samples.txt "$folder_name"_junc_coor_with_junction_ID_more_than_"$threshold"_reads.txt > "$folder_name"_junc_coor_with_junction_ID_more_than_"$threshold"_reads_overlap_from_all_samples.txt;

awk '{print $1 "\t" $4 "\t" $2 "\t" $3 "\t" $5}' "$folder_name"_junc_coor_with_junction_ID_more_than_"$threshold"_reads_overlap_from_all_samples.txt > "$folder_name"_junc_coor_with_junction_ID_more_than_"$threshold"_reads_overlap_from_all_samples_formatted.txt;

awk '{print $1 "\t" $2 "\t" $3 "\t" $4 "\t" $4-$3 "\t" $5}' "$folder_name"_junc_coor_with_junction_ID_more_than_"$threshold"_reads_overlap_from_all_samples_formatted.txt > "$folder_name"_junc_coor_with_junction_ID_more_than_"$threshold"_reads_overlap_from_all_samples_formatted_with_junction_length.txt;


