#!/usr/bin/perl
use strict;
use warnings;
use List::Util qw( min max );
use List::Util qw(sum);
#data_file_1=non_zero_profiled_total_alternative_splicing_event_junction_first_processing_for_DEXSeq_reference_building.txt; data_file_2=ctrl1_remap_junction_counts.txt; data_file_3=CTRL1_fn_count.txt; 

my $len=scalar(@ARGV);
if ($len < 1) {
    die "Usage:output_reformat_JUM_1.pl <data_file_1>\n";

}

my ($data_file_1)  = @ARGV;

my $fold;
open(IN1, "<$data_file_1") or die "can't open input1 file: $!";

while(<IN1>) {
      chomp;
      if($_ !~ /raw_count/) {
      my $ori=$_;
      my @array=split(/\s+/,$_);
      $array[23] =~ s/%//;
      $array[24] =~ s/%//;
      $array[25] =~ s/%//;
      $array[26] =~ s/%//;
      $array[27] =~ s/%//;
      $array[28] =~ s/%//;
      $array[29] =~ s/%//;
      $array[30] =~ s/%//;
      my $av1=sum($array[23],$array[24],$array[25], $array[26])/4/100;
      my $av2=sum($array[27],$array[28],$array[29], $array[30])/4/100;
      #my $max=max($av1,$av2)/100;
      #my $min=min($av1,$av2)/100;
      #if($min == 0) {$fold="INF";}
      #else{
      #$fold=$max/$min/2;}
      my $dpsi=$av1-$av2;
      print $ori; print "\t"; print $dpsi; print "\n"; #print $av1/100; print "\t"; print $av2/100; print "\t"; print $max; print "\t"; print $min; print "\t"; print $fold; print "\n";
      }
      else {
        print $_; print "\t"; print "deltaPSI"; print "\n";
      }

}

close IN1;


       



