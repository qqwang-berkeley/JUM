#!/bin/bash
#set -e
# $1=directory for JUM scripts; $2=pvalue or pvalue-adjusted; $3=pvalue or padj threshold; $4=file numbers; $5=control_file_numbers; 
#############

#folder="$1";
#pvalue_padj="$2";
#cutoff="$3";
#file_num="$4";
#con_file_num="$5";
#############

################# profiling splicing patterns ##########################
perl $folder/profiling_splicing_patterns_from_AS_events_1.pl *profiled_total_AS_event_junction_first_processing_for_JUM_reference_building.txt UNION_mixed_event_screening.txt reconstruct_splicing_pattern_input_1.txt;
perl $folder/profiling_splicing_patterns_from_AS_events_2.pl reconstruct_splicing_pattern_input_1.txt reconstruct_splicing_pattern_input_2.txt;
perl $folder/profiling_splicing_patterns_from_AS_events_3_updated.pl reconstruct_splicing_pattern_input_1.txt reconstruct_splicing_pattern_input_2.txt total_A5SS_event.txt total_A3SS_event.txt total_cassette_exon_event.txt total_mixed_event.txt;
################# profiling splicing patterns ##########################


