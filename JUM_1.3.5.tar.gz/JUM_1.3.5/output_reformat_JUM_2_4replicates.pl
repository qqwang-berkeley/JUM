#!/usr/bin/perl
use strict;
use warnings;
use List::Util qw( min max );
use List::Util qw(sum);
#data_file_1=non_zero_profiled_total_alternative_splicing_event_junction_first_processing_for_DEXSeq_reference_building.txt; 

my $len=scalar(@ARGV);
if ($len < 1) {
    die "Usage:output_reformat_2.pl <data_file_1>\n";

}

my ($data_file_1)  = @ARGV;

my $o=0;
my %hash; #$hash{chr}{strand}{start}{end}=[count_number];
open(IN1, "<$data_file_1") or die "can't open input1 file: $!";

my @enter_1;
$#enter_1=8;
my @enter_2;
$#enter_2=8;
my @enter_3;
$#enter_3=8;
my @enter_4;
$#enter_4=8;
my $count=0;
my $indicator_1;
my $indicator_2;
my $ratio_a;
my $ratio_b;
my $ratio_c;
my $ratio_d;
my $ratio_e;
my $ratio_f;
my $ratio_g;
my $ratio_h;
my $dpsi;
my $av1;
my $av2;



while(<IN1>) {
      chomp;
    if($_ !~ /raw_count/) {
      $count=$count+1;
      my $ori=$_;
      my @array=split(/\s+/,$_);
         if($count % 4 == 1) {
           $enter_1[0]=$array[15];
           $enter_1[1]=$array[16];
           $enter_1[2]=$array[17];
           $enter_1[3]=$array[18];
           $enter_1[4]=$array[19];
           $enter_1[5]=$array[20];
	   $enter_1[6]=$array[21];
	   $enter_1[7]=$array[22];
	   print $ori; print "\n";
         } 
         if($count % 4 == 2) {
           $enter_2[0]=$array[15];
           $enter_2[1]=$array[16];
           $enter_2[2]=$array[17];
           $enter_2[3]=$array[18];
           $enter_2[4]=$array[19];
           $enter_2[5]=$array[20];
	   $enter_2[6]=$array[21];
	   $enter_2[7]=$array[22];
	   print $ori; print "\n";
         }
         if($count % 4 == 3) {
           $enter_3[0]=$array[15];
           $enter_3[1]=$array[16];
           $enter_3[2]=$array[17];
           $enter_3[3]=$array[18];
           $enter_3[4]=$array[19];
           $enter_3[5]=$array[20];
	   $enter_3[6]=$array[21];
	   $enter_3[7]=$array[22];
	   print $ori; print "\n";
         }
         if($count % 4 == 0) {
           $enter_4[0]=$array[15];
           $enter_4[1]=$array[16];
           $enter_4[2]=$array[17];
           $enter_4[3]=$array[18];
           $enter_4[4]=$array[19];
           $enter_4[5]=$array[20];
	   $enter_4[6]=$array[21];
	   $enter_4[7]=$array[22];
	   $indicator_1=0;
	   $indicator_2=0;
	   if($enter_1[0]+$enter_2[0]+$enter_3[0] != 0) {
                $ratio_a=($enter_2[0]+$enter_3[0])/($enter_1[0]+$enter_2[0]+$enter_3[0]);
		$indicator_1=$indicator_1+1;
	   }
           else {
		$ratio_a=0;
	   }
	   if($enter_1[1]+$enter_2[1]+$enter_3[1] != 0) {
	        $ratio_b=($enter_2[1]+$enter_3[1])/($enter_1[1]+$enter_2[1]+$enter_3[1]);
                $indicator_1=$indicator_1+1;
	   }
	   else {
		$ratio_b=0;
	   }
	   if($enter_1[2]+$enter_2[2]+$enter_3[2] != 0) {
                $ratio_c=($enter_2[2]+$enter_3[2])/($enter_1[2]+$enter_2[2]+$enter_3[2]);
                $indicator_1=$indicator_1+1;
	   }
	   else {
	        $ratio_c=0;
	   }
           if($enter_1[3]+$enter_2[3]+$enter_3[3] != 0) {	   
		$ratio_d=($enter_2[3]+$enter_3[3])/($enter_1[3]+$enter_2[3]+$enter_3[3]);
                $indicator_1=$indicator_1+1;
	   }
	   else {
		$ratio_d=0;
	   }
	   if($enter_1[4]+$enter_2[4]+$enter_3[4] != 0) {	
		$ratio_e=($enter_2[4]+$enter_3[4])/($enter_1[4]+$enter_2[4]+$enter_3[4]);
	        $indicator_2=$indicator_2+1; 
	   }
	   else {
		$ratio_e=0;
	   }
	   if($enter_1[5]+$enter_2[5]+$enter_3[5] != 0) {
	        $ratio_f=($enter_2[5]+$enter_3[5])/($enter_1[5]+$enter_2[5]+$enter_3[5]);
	        $indicator_2=$indicator_2+1;
	   }
	   else {
		$ratio_f=0;
	   }
	   if($enter_1[6]+$enter_2[6]+$enter_3[6] != 0) {
	        $ratio_g=($enter_2[6]+$enter_3[6])/($enter_1[6]+$enter_2[6]+$enter_3[6]);
                $indicator_2=$indicator_2+1;
	   }
	   else {
	        $ratio_g=0;
	   }
           if($enter_1[7]+$enter_2[7]+$enter_3[7] != 0) {	   
		$ratio_h=($enter_2[7]+$enter_3[7])/($enter_1[7]+$enter_2[7]+$enter_3[7]);
                $indicator_2=$indicator_2+1;
	   }
	   else {
		$ratio_h=0;
	   }
	   if(($indicator_1 != 0) && ($indicator_2 != 0)) {
	   $av1=sum($ratio_a,$ratio_b,$ratio_c,$ratio_d)/$indicator_1;
	   $av2=sum($ratio_e,$ratio_f,$ratio_g,$ratio_h)/$indicator_2;
	   $dpsi=$av1-$av2;
           }
	   else {
		  $dpsi="INF";
	  } 
           print $ori; print "\t"; print $dpsi; print "\n"; #print $ratio_a; print "\t";print $ratio_b; print "\t";print $ratio_c; print "\t";print $ratio_d; print "\t"; print $av1; print "\t"; print $av2; print "\t"; print $ma; print "\t"; print $mi; print "\t"; print $fold; print "\n";         }
          }
      }
      else {
         print $_; print "\t"; print "deltaPSI"; print "\n";
      }
}



   
   
   
   
       



